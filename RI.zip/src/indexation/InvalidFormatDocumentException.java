package indexation;

public class InvalidFormatDocumentException extends Exception {

	public InvalidFormatDocumentException() {
		// TODO Auto-generated constructor stub
	}

	public InvalidFormatDocumentException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public InvalidFormatDocumentException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public InvalidFormatDocumentException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public InvalidFormatDocumentException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

}
