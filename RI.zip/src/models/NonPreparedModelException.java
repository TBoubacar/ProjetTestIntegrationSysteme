package models;

public class NonPreparedModelException extends Exception {
	public NonPreparedModelException(String s) {
		super(s);
	}
}
